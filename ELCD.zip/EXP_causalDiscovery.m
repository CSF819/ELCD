clc;clear;
addpath(genpath('.\algo'));%����·��
 %[skeleton,names] = readRnet( '.\dataset\cancer.net');
[skeleton,names] = readRnet( '.\dataset\asia.net');%�������
%[skeleton,names] = net2sketelon( '.\dataset\insurance.net');
% [skeleton,names] = net2sketelon( '.\dataset\Alarm.net');
%[skeleton,names] = readRnet( '.\dataset\barley.net');
%[skeleton,names] = net2sketelon( '.\dataset\hailfinder.net');
 %[skeleton,names] = net2sketelon( '.\dataset\win95pts.net');
    skeleton = sortskeleton(skeleton);%�������
    %nSample = [25,50,100,150,200];
%for j=1:5
    %j
    k=10;
    CE=zeros(size(skeleton,1));
    %time3=[];
    %Score=zeros(k,9);
    ScoreP=zeros(k,15);
for i = 1:k
    data = SEMDataGenerator(skeleton, 500, 'uniform', 0.3);%�������
    %start3=tic
    [ScoreP(i,:),CEA,csk,dsk,esk]=PC_PaCoTest_EL(data,skeleton,3);
    %[ScoreK(i,:),~]=PC_KCIT_EL(data,skeleton,3);
    %[Score_paca(i,:)]=PC_Old(data,skeleton);
    %[Score(i,:),~]=PC_RCIT_ELCD(data,skeleton,3);
    CE=CE+CEA;
    %time3(i)=toc(start3);
end
MCE=CE./k;
%ScoreP
%mean(ScoreK)
%mean(Score)
MS=mean(ScoreP)
Sstd=std(ScoreP);
save('asia.mat', 'MS', 'Sstd', 'MCE');

%time3=mean(time3)
%end

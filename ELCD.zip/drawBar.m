clc;clear;
load('C:\Users\csf81\Desktop\EL_Causal_Direction_Code\Result\alarm_exp.mat')
% 数据准备
categories = {'Recall', 'Precision', 'F1', 'FPR'};
Csk = MS(1:4);
Dsk = MS(6:9);
Esk = MS(11:14);

% 绘制分组柱状图
x = 1:length(categories);
width = 0.9;
figure;
bar(x, [Csk' Dsk' Esk'], width, 'LineWidth', 1);

% 设置柱子属性
 colors = [115,171,245; 60,185,252; 68,114,196];
 colors=colors./255;
 bars = get(gca, 'Children');
set(gca, 'Children');
for i = 1:length(bars)
    bar = bars(i);
    set(bar, 'FaceColor', colors(i,:));
end

% 设置x轴刻度标签
xticks(x);
xticklabels(categories);

% 添加图例
legend('Csk', 'Dsk', 'Esk');

% 添加标题和标签
%title('Insurance');
xlabel('Metric','FontSize', 7.5);

% 调整柱子位置

% 添加数值标签
for i = 1:length(categories)
    text(x(i)-width, Csk(i)+10, num2str(Csk(i)), 'HorizontalAlignment', 'center');
    text(x(i), Dsk(i)+10, num2str(Dsk(i)), 'HorizontalAlignment', 'center');
    text(x(i)+width, Esk(i)+10, num2str(Esk(i)), 'HorizontalAlignment', 'center');
end


% 设置网格线
grid on;
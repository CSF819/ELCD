addpath(genpath('.\algo'));%添加路径
a=MCE;
for i=1:27
    for j=1:27
        if a(i,j)~=0
            a(i,j)=1;
        end
    end
end
a=sortskeleton(a);
G = digraph(a);
plot(G, 'LineWidth', 2, 'ArrowSize', 10, 'NodeFontSize', 14,'Layout', 'auto');
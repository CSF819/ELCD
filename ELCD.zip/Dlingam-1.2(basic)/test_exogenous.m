function [  ] = test_exogenous(  )%%%%����
clear all;clc;
dims=20;
a=zeros(dims,6);
randseed=10;
indegree=[1:3];
B=zeros(dims,6);
R = zeros(randseed,dims,6);%%%��ʾrandseed��dims*4������
A=cell(1,3);
for k=1:3
    for j=1:10
        for i=2:dims
            i
            [kkk,kest,MSE,number_connect_edge,TP,true_absence_identified,FN,FP,timeTotal,Srcc]=testDlingamboot(i,j,k);
            Recall=TP/(TP+FN);
            Percision=TP/(TP+FP);
            F1=2*(Recall*Percision)/(Recall+Percision);
            a(i,:)=[MSE,Recall,Percision,F1,timeTotal,Srcc]';
        end
        R(j,:,:)=a;
    end
    B(:,1)=mean(R(:,:,1)',2);%%%ÿһ�еľ�ֵ
    B(:,2)=mean(R(:,:,2)',2);
    B(:,3)=mean(R(:,:,3)',2);
    B(:,4)=mean(R(:,:,4)',2);
    B(:,5)=mean(R(:,:,5)',2);
    B(:,6)=mean(R(:,:,6)',2);
    A{k}=B;
end
a1=A{1};
a2=A{2};
a3=A{3};
xlswrite('Lap_sparse.xls', a1,'indegree1');
xlswrite('Lap_sparse.xls', a2,'indegree2');
xlswrite('Lap_sparse.xls', a3,'indegree3');
disp('finished');
end

